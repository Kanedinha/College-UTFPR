#include<stdio.h>

int main(){

	char ra[30][20];

	
}