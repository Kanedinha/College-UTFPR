O arquivo Id j� deve ser criado com '0' dentro dele, 
n�o consegui cri�-lo j� com '0' sem causar interfer�ncia nos futuros arquivos.

Caio Henrique Pedroso Pedro me ajudou muito nessa APS.

ele me orientou na parte das resposabilidades