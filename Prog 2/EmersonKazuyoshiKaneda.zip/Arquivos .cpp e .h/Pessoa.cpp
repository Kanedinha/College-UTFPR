#include "Pessoa.h"

using namespace std;

    void Pessoa:: setNome(string nome){ this->nome = nome;};
    string Pessoa:: getNome(){ return nome;};

    void Pessoa:: setId(int id){ this->id = id;};
    int Pessoa:: getId(){ return id;};
