#ifndef SeparaString_h
#define SeparaString_h

#include <iostream>
#include <string.h>
#include <string>

using namespace std;

class SeparaStr{
public:
	void SeparaDadosEmUmVetor(string vetor[], string linha);
};

#endif