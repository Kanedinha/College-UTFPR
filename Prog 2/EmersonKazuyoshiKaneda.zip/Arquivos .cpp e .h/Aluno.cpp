#include "Aluno.h"

using namespace std;
    

    void Aluno:: setFaculdade(string faculdade){ this->faculdade = faculdade;};
    string Aluno:: getFaculdade(){ return this->faculdade;};

    void Aluno:: setCurso(string curso){ this->curso = curso;};
    string Aluno:: getCurso(){ return this->curso;};

