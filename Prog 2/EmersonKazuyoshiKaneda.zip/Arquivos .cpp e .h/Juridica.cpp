#include "Juridica.h"

using namespace std;

    void Juridica:: setCnpj(string cnpj){ this->cnpj = cnpj;};
    string Juridica:: getCnpj(){ return this->cnpj;};
