#include "Fisica.h"

using namespace std;

	// define o cpf
    void Fisica:: setCpf(string cpf){ this->cpf = cpf;};
   	// acessa o cpf
    string Fisica:: getCpf(){ return this->cpf;};


    void Fisica:: setIdade(int idade){ this->idade = idade;};
	
	int Fisica:: getIdade(){ return this->idade;};
